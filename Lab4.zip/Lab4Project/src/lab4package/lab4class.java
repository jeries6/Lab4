package lab4package;

public class lab4class {

	public static void main(String[] args) {
		
		/**init printrepeat object and run it's functions */
		PrintRepeat printt = new PrintRepeat();
		
		printt.init();
		printt.print();
		

	}

}
