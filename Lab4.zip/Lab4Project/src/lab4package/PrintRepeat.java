package lab4package;

public class PrintRepeat {

	int repeatednum;
	
	/** init array and fill numbers */
	public void init() {
		
	RepeatetNum test = new RepeatetNum();
	test.fillarray();
	repeatednum = test.findRepeat();
	}
	
	/** prints the repeated number */ 
	public void print() {
		System.out.println(repeatednum);
	}
}
