/**Lab4package */
package lab4package;

import java.util.Random;
/**repeatedNum Class for the array*/
public class RepeatetNum {
	
	/** Generate random numbers for the array*/
	Random rand = new Random();
	
	/** array of integers */
	public int[] intarray = new int[20];
	
	/**fill array with random numbers from 1-20*/
	public void fillarray() {
	for (int i=0; i<20;i++)
	{
		intarray[i] = (rand.nextInt(19)+1);
	}
	}
	
	/**FindRepeat finds the repeated number in the array and returns it
	 * @return Returns the repeated number
	 *  
	 *  */
	 
	public int findRepeat()
	{
		for (int i=0;i<20;i++)
		{
			for (int j=0;j<20;j++) 
			{
				if(intarray[i] == intarray[j])
					return intarray[i];
			}
		}
		return 0;
	}
}
